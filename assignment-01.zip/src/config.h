#ifndef __CONFIG__
#define __CONFIG__

#define N 4

#define LED_PIN1 2
#define LED_PIN2 3
#define LED_PIN3 4
#define LED_PIN4 5

#define LED_RED_PIN 11

#define BUT_PIN1 8
#define BUT_PIN2 9
#define BUT_PIN3 10
#define BUT_PIN4 12

#define POT_PIN A0

#endif