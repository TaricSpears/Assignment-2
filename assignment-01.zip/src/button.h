#ifndef _BUTTON_H_
#define _BUTTON_H_

void buttons_init();

bool get_button_value(int index);

void reset_button_state();
#endif