Gruppo composto da:
- Bartoli Davide
- Pietro Sbaraccani